## Convert between Pulseq and TOPPE file formats

Requires:

1. The +mr Pulseq Matlab package, provided here in the ./+mr/ folder.
2. The +toppe Matlab package.


