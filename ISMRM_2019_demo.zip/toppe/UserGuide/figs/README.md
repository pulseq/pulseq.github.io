To create pdf figure files, run makefigs:
```
./makefigs
```
