# Source files for TOPPE user guide

To generate the user guide pdf:
```
./doit
```

A link to the the TOPPE user guide can be found on the TOPPE website: https://toppemri.github.io/.

For questions about TOPPE, contact Jon-Fredrik Nielsen at jfnielse@umich.edu.
