## Complete sequence examples

If you're not able to compile the mex files for the SLR toolbox, try using the Matlab scripts instead by copying them to somewhere in your path:
```
$ cp ../../+toppe/+utils/+rf/+jpauly/matlab/ .
```
