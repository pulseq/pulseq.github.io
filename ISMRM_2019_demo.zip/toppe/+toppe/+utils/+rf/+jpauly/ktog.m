function g = ktog(k,dt)

g = diff(k)/(4.257*dt);

