addpath(genpath('pulseq'));
addpath(genpath('mapVBVD'));
addpath('toppe');
cd pulseq/matlab
edit demoSeq/gre_live_demo.m
