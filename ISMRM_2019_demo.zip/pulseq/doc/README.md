<div align="center">
<a href="http://pulseq.github.io/" target="_blank">
<img src="http://pulseq.github.io/logo_hires.png" width="250" alt="Pulseq logo"></img>
</a>
</div>

# Website

This repository stores the public website automatically generated from the *Pulseq* source code using doxygen and matlab. The resulting website is accessible here:

http://pulseq.github.io/

The source code is here: https://github.com/pulseq/pulseq

